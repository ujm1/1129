package bus;

public class Main {
    public static void main(String[] args) {
        Bus bus2=new Bus(200,75,50, 0);
        bus2.start();
    }
}